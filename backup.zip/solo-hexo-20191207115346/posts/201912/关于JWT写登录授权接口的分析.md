title: 关于JWT写登录授权接口的分析
date: '2019-12-05 09:46:22'
updated: '2019-12-06 16:19:22'
tags: [技术分享]
permalink: /articles/2019/12/05/1575510382859.html
---
![](https://img.hacpai.com/bing/20180118.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 前情概要

目前已经实现了一版逻辑，想要在这个基础上进行更多更多的细节扩展，比如扩展 token 的保存时间，这时候就需要增加 refresh_token 来请求新的 token 数据

# 解决方案
解决方案这里分两种情况说明，当前的解决方案、扩展的解决方案
## 当前的解决方案
当前的解决方案主要是基于标准的JWT加密的token返回，设置时限(这里以30分钟为例)，利用redis存储双倍的时间来进行后续接口请求的验证，如果超过时限但是在2倍时限之内的话，返回对应的授权需要重新请求的状态码，当判断获取到状态码之后，用现有的token去请求刷新接口，这个接口验证token时验证是否在时限和双倍时限之间，如果是，重新返回新的token，如果token超过了双倍时限，那么则拒绝请求，必须重新请求登录授权获取。
这里的redis中存储的键值可以做一些处理，来验证token信息的可靠性
防止token被利用，所以时间可以尽可能的少一些
## 扩展的解决方案构思
首先是按照正常方式来授权获取token，同时不带access_token及refresh_token，两种token中得数据类型不同，其中得加密方式也可以不同，在拦截器中判断传入的方式从而实现不同的业务逻辑。
**在刷新token时，会作废掉refresh_token，这样可以保证长期登录，如果超过一个月不登陆，那么在redis里面的数据就会消失，因为在redis里面保存了最长30天的数据，而access_token则只保存2小时**

## 最终接口形态

### 1. 登录授权

请求方式：POST

数据格式：JSON

请求参数:

| 参数| 描述 |
| --- | --- | 
| username | 登录用户名 |  
| smscode | 短信验证码 |  

  

响应结果：

```
{  
    "code": 200,  
    "data": {  
        "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1NzU1NDAxMDk5NDgsInBheWxvYWQiOiJ7XCJtZXJjaGFudGlkXCI6MTEwMixcIm5hbWVcIjpcIuWFqOaZr-inhuinieWKoOebn1wiLFwiaWRcIjoxMTAyMDAwMSxcImFnZW5jeW5vXCI6XCIwMDMwMDFcIixcImVtYWlsXCI6XCIxMjNAMTIzLmNuXCJ9In0.TfnSxoXbHs4ckaI-M1i8AmmDCTWWp52x3BTcYdqNNBA",  
        "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1NzgxMjQ5MDk5NzksInBheWxvYWQiOiJ7XCJ1c2VybmFtZVwiOlwiMTUwMTExNDUyMDBcIn0ifQ.Aao1veTc_DEQLih2EmxjBf2B80LO4b4zgA6lgxloR_4",  
        "expires_in": 7200,  
        "info": {  
            "merchantid": 1102,  
            "name": "name",  
            "id": 11020001,  
            "agencyno": "003001",  
            "email": "123@[123.cn](http://123.cn/)"  
        }  
    },  
    "message": "Ok"  
}
```

### 2.刷新授权


请求方式：POST

数据格式：JSON


| :-- |  :-- |  :-- |
| **app-refresh-token** |  Header |  登录授权时获取到的refresh_token值，正常可以保存30天，当使用刷新授权后，该refresh_token失效，再次请求刷新请使用最新获取到refresh_token，如果请求都不可用，则需要用户重新登录，该内容需要客户端严格保存 |
| **app-access-token** |  Header |  登录授权时获取到的access_token值，正常保存2小时，2小时后失效，失效后需要调用该接口用refresh_token获取最新并保存到客户端 |

响应结果：

```
{  
    "code": 200,  
    "data": {  
        "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1NzU1NDAxMDk5NDgsInBheWxvYWQiOiJ7XCJtZXJjaGFudGlkXCI6MTEwMixcIm5hbWVcIjpcIuWFqOaZr-inhuinieWKoOebn1wiLFwiaWRcIjoxMTAyMDAwMSxcImFnZW5jeW5vXCI6XCIwMDMwMDFcIixcImVtYWlsXCI6XCIxMjNAMTIzLmNuXCJ9In0.TfnSxoXbHs4ckaI-M1i8AmmDCTWWp52x3BTcYdqNNBA",  
        "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1NzgxMjQ5MDk5NzksInBheWxvYWQiOiJ7XCJ1c2VybmFtZVwiOlwiMTUwMTExNDUyMDBcIn0ifQ.Aao1veTc_DEQLih2EmxjBf2B80LO4b4zgA6lgxloR_4",  
        "expires_in": 7200  
    },  
    "message": "Ok"  
}
```
