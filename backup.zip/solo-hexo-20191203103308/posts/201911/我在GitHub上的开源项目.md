title: 我在 GitHub 上的开源项目
date: '2019-11-18 17:01:42'
updated: '2019-11-18 17:01:42'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [GoogleTranslate](https://github.com/remixjc/GoogleTranslate) <kbd title="主要编程语言">C#</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/remixjc/GoogleTranslate/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/remixjc/GoogleTranslate/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/remixjc/GoogleTranslate/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.remixjc.cn`](http://www.remixjc.cn "项目主页")</span>

This is GoogleTranslate by translate.google.cn project.



---

### 2. [solo-blog](https://github.com/remixjc/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/remixjc/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/remixjc/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/remixjc/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.remixjc.cn`](http://www.remixjc.cn "项目主页")</span>

Hack Jc - 记录精彩人生



---

### 3. [googletranslate-wx](https://github.com/remixjc/googletranslate-wx) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/remixjc/googletranslate-wx/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/remixjc/googletranslate-wx/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/remixjc/googletranslate-wx/network/members "分叉数")</span>

微信小程序 GoogleTranslate项目，名称：转运草，可以小程序搜索关注



---

### 4. [googletranslate-nodejs](https://github.com/remixjc/googletranslate-nodejs) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/remixjc/googletranslate-nodejs/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/remixjc/googletranslate-nodejs/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/remixjc/googletranslate-nodejs/network/members "分叉数")</span>

googletranslate for nodejs

