title: JetBrains全系列软件激活教程激活码以及JetBrains系列软件汉化包
date: '2019-12-05 20:44:28'
updated: '2019-12-05 20:44:28'
tags: [技术分享]
permalink: /articles/2019/12/05/1575549868694.html
---
> JetBrains全系列软件激活教程，共有两种方法，喜欢哪种用哪种。另外附上JetBrains系列软件的汉化包以及中文设置教程，希望大家喜欢。

# 写在前面的话

### MacWk.com建议大家去 [JetBrains官网](https://www.jetbrains.com/) 下载JetBrains系列工具的官方版，然后使用本教程方法激活。

# 一、激活

可成功激活JetBrains以下版本（支持低于以下版本的激活）：

> * IntelliJ IDEA 2019.2.5激活
> * AppCode 2019.2.5激活
> * CLion 2019.2.5激活
> * DataGrip 2019.2.5激活
> * GoLand 2019.2.5激活
> * PhpStorm 2019.2.5激活
> * PyCharm 2019.2.5激活
> * Rider 2019.2.3激活
> * RubyMine 2019.2.5激活
> * WebStorm 2019.2.4激活

### 方法一：简单粗暴直接使用以下激活码

> 此激活不绑定账户！是企业激活码分配的，属于商业激活，个人账户无法持有，不过也是最简单粗暴的，支持JetBrains最新版本，不怕升级 (激活请选Activation code)

```
D6KY031L1G-eyJsaWNlbnNlSWQiOiJENktZMDMxTDFHIiwibGljZW5zZWVOYW1lIjoi5o6I5p2D5Luj55CG5ZWGOiB3d3cuaTkub3JnIiwiYXNzaWduZWVOYW1lIjoiIiwiYXNzaWduZWVFbWFpbCI6IiIsImxpY2Vuc2VSZXN0cmljdGlvbiI6IiIsImNoZWNrQ29uY3VycmVudFVzZSI6ZmFsc2UsInByb2R1Y3RzIjpbeyJjb2RlIjoiSUkiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA3LTIyIiwicGFpZFVwVG8iOiIyMDIwLTA3LTIxIn0seyJjb2RlIjoiQUMiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA3LTIyIiwicGFpZFVwVG8iOiIyMDIwLTA3LTIxIn0seyJjb2RlIjoiRFBOIiwiZmFsbGJhY2tEYXRlIjoiMjAxOS0wNy0yMiIsInBhaWRVcFRvIjoiMjAyMC0wNy0yMSJ9LHsiY29kZSI6IlBTIiwiZmFsbGJhY2tEYXRlIjoiMjAxOS0wNy0yMiIsInBhaWRVcFRvIjoiMjAyMC0wNy0yMSJ9LHsiY29kZSI6IkdPIiwiZmFsbGJhY2tEYXRlIjoiMjAxOS0wNy0yMiIsInBhaWRVcFRvIjoiMjAyMC0wNy0yMSJ9LHsiY29kZSI6IkRNIiwiZmFsbGJhY2tEYXRlIjoiMjAxOS0wNy0yMiIsInBhaWRVcFRvIjoiMjAyMC0wNy0yMSJ9LHsiY29kZSI6IkNMIiwiZmFsbGJhY2tEYXRlIjoiMjAxOS0wNy0yMiIsInBhaWRVcFRvIjoiMjAyMC0wNy0yMSJ9LHsiY29kZSI6IlJTMCIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDctMjIiLCJwYWlkVXBUbyI6IjIwMjAtMDctMjEifSx7ImNvZGUiOiJSQyIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDctMjIiLCJwYWlkVXBUbyI6IjIwMjAtMDctMjEifSx7ImNvZGUiOiJSRCIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDctMjIiLCJwYWlkVXBUbyI6IjIwMjAtMDctMjEifSx7ImNvZGUiOiJQQyIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDctMjIiLCJwYWlkVXBUbyI6IjIwMjAtMDctMjEifSx7ImNvZGUiOiJSTSIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDctMjIiLCJwYWlkVXBUbyI6IjIwMjAtMDctMjEifSx7ImNvZGUiOiJXUyIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDctMjIiLCJwYWlkVXBUbyI6IjIwMjAtMDctMjEifSx7ImNvZGUiOiJEQiIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDctMjIiLCJwYWlkVXBUbyI6IjIwMjAtMDctMjEifSx7ImNvZGUiOiJEQyIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDctMjIiLCJwYWlkVXBUbyI6IjIwMjAtMDctMjEifSx7ImNvZGUiOiJSU1UiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA3LTIyIiwicGFpZFVwVG8iOiIyMDIwLTA3LTIxIn1dLCJoYXNoIjoiMTM3ODQzMjAvMCIsImdyYWNlUGVyaW9kRGF5cyI6NywiYXV0b1Byb2xvbmdhdGVkIjpmYWxzZSwiaXNBdXRvUHJvbG9uZ2F0ZWQiOmZhbHNlfQ==-hBov92HEvNGvBzS2z190KAPxc9F6XY6jT1daMLlPrpCSEAdQX/955WkyGz+hCa3w/aeNExMEZIv2tALkFDOt857w4PZM8oYZ07s7My1NL7DxX9coFswbC6IIBijkAne9cPV9fSnGt5XcfsAkrF8KW1gj21H4EZGR6Jm4Cn7/j37rG1ASu2uvdoJ4dgCicfi78fvIw+zVvGm7L4cMjsmsilNNrUFPpDuVCp2kfU2ncDWm/M0lu+Dfeo3UO61/ICs9FvYAw0V4d8Q6pExzoqbAGH0IgkrHKJ2YQpKKOz3/+w4SGKhAX+85XYmfmLcUoqAZWaI95yhXN/czf/eeAf3ZEg==-MIIElTCCAn2gAwIBAgIBCTANBgkqhkiG9w0BAQsFADAYMRYwFAYDVQQDDA1KZXRQcm9maWxlIENBMB4XDTE4MTEwMTEyMjk0NloXDTIwMTEwMjEyMjk0NlowaDELMAkGA1UEBhMCQ1oxDjAMBgNVBAgMBU51c2xlMQ8wDQYDVQQHDAZQcmFndWUxGTAXBgNVBAoMEEpldEJyYWlucyBzLnIuby4xHTAbBgNVBAMMFHByb2QzeS1mcm9tLTIwMTgxMTAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxcQkq+zdxlR2mmRYBPzGbUNdMN6OaXiXzxIWtMEkrJMO/5oUfQJbLLuMSMK0QHFmaI37WShyxZcfRCidwXjot4zmNBKnlyHodDij/78TmVqFl8nOeD5+07B8VEaIu7c3E1N+e1doC6wht4I4+IEmtsPAdoaj5WCQVQbrI8KeT8M9VcBIWX7fD0fhexfg3ZRt0xqwMcXGNp3DdJHiO0rCdU+Itv7EmtnSVq9jBG1usMSFvMowR25mju2JcPFp1+I4ZI+FqgR8gyG8oiNDyNEoAbsR3lOpI7grUYSvkB/xVy/VoklPCK2h0f0GJxFjnye8NT1PAywoyl7RmiAVRE/EKwIDAQABo4GZMIGWMAkGA1UdEwQCMAAwHQYDVR0OBBYEFGEpG9oZGcfLMGNBkY7SgHiMGgTcMEgGA1UdIwRBMD+AFKOetkhnQhI2Qb1t4Lm0oFKLl/GzoRykGjAYMRYwFAYDVQQDDA1KZXRQcm9maWxlIENBggkA0myxg7KDeeEwEwYDVR0lBAwwCgYIKwYBBQUHAwEwCwYDVR0PBAQDAgWgMA0GCSqGSIb3DQEBCwUAA4ICAQAF8uc+YJOHHwOFcPzmbjcxNDuGoOUIP+2h1R75Lecswb7ru2LWWSUMtXVKQzChLNPn/72W0k+oI056tgiwuG7M49LXp4zQVlQnFmWU1wwGvVhq5R63Rpjx1zjGUhcXgayu7+9zMUW596Lbomsg8qVve6euqsrFicYkIIuUu4zYPndJwfe0YkS5nY72SHnNdbPhEnN8wcB2Kz+OIG0lih3yz5EqFhld03bGp222ZQCIghCTVL6QBNadGsiN/lWLl4JdR3lJkZzlpFdiHijoVRdWeSWqM4y0t23c92HXKrgppoSV18XMxrWVdoSM3nuMHwxGhFyde05OdDtLpCv+jlWf5REAHHA201pAU6bJSZINyHDUTB+Beo28rRXSwSh3OUIvYwKNVeoBY+KwOJ7WnuTCUq1meE6GkKc4D/cXmgpOyW/1SmBz3XjVIi/zprZ0zf3qH5mkphtg6ksjKgKjmx1cXfZAAX6wcDBNaCL+Ortep1Dh8xDUbqbBVNBL4jbiL3i3xsfNiyJgaZ5sX7i8tmStEpLbPwvHcByuf59qJhV/bZOl8KqJBETCDJcY6O2aqhTUy+9x93ThKs1GKrRPePrWPluud7ttlgtRveit/pcBrnQcXOl1rHq7ByB8CFAxNotRUYL9IF5n3wJOgkPojMy6jetQA5Ogc8Sm7RG6vg1yow==
```

### 方法二：自己使用github账号授权生成激活码

大家熟知Jetbrains的话应该知道：他们家的所有产品升级到2018.2.1及以上版本后，先前可用的注册服务器都失效了，无法激活升级到最新版本体验最新黑科技。

这次要送的这份礼就是： Jetbrains全系列产品2019.2.3及以下版本（理论上适用于目前所有新老版本）最新注册服务器（License Server）的破解，可使用它来激活你手头上的Jetbrains IDE。

[百度网盘下载，提取码(password)：mmk6。](https://pan.baidu.com/s/1FGZ9d5J5amnvf0vMFqSOsQ)

具体使用方法已写在压缩包的 README.pdf / README.txt内（包内另附操作截图）。

> 支持Activation code注册码激活（适用于自定义JetBrains License name的朋友），可用于网络不佳或离线环境。

[去生成](https://zhile.io/custom/license)

此方法来自于：[https://zhile.io](https://zhile.io/custom/license)

# 二、中文汉化包

JetBrains系列汉化包可用于：

> * Android Studio 3.5 汉化包
> * CLion 2019.2 汉化包
> * DataGrip 2019.2 汉化包
> * GoLand 2019.2 汉化包
> * IntelliJ IDEA 2019.2 汉化包
> * PhpStorm 2019.2 汉化包
> * PyCharm 2019.2 汉化包
> * Rider 2019.2 汉化包
> * RubyMine 2019.2 汉化包
> * WebStorm 2019.2 汉化包

汉化来自于：[https://www.pingfangx.com](https://www.pingfangx.com/)

### 下载

[GitHub下载](https://github.com/pingfangx/TranslatorX)

[百度网盘下载(提取码:2222)](https://pan.baidu.com/share/init?surl=caVKxCakmbF9Cr_7Em1pfQ)

### 使用

将 resources_zh_CN_*.jar ，放到软件安装路径下的 **lib** 目录中，重启软件即可

* 注意是 **lib** 不是 **bin**
* 不需要重命名，不需要解压，不需要删除任何 jar 包，不会覆盖任何 jar 包
* 软件安装路径的 lib 目录示例 `D:\software\JetBrains\AndroidStudio\lib`
* 该目录下应该有一个文件: resources_en.jar 如果没有，说明没有找对路径
* MAC 用户请在 Finder > 应用程序 中找到软件，右键 > 显示包内容

### 反馈

请认真阅读 [使用方法] 。  
请查阅下方的常见问题。  
如果还有疑问，可提 issue反馈。

* [issue](https://www.pingfangx.com/xx/translation/jetbrains/feedback/issues)

### 常见问题

#### 汉化不生效

0. 当前语言环境不是中文（zh_CN）  
    请打开软件，选择 Help → Edit Custom VM Options...  
    加上两行  
    -Duser.language=zh  
    -Duser.region=CN  
    然后重启软件

#### 设置打不开

系统原本的 resources_en.jar 被损坏，请重新安装恢复该 jar 包，按正确 [使用方法] 重新使用汉化包。

常见原因

* 不需要将汉化包内容解压到 resources_en.jar 中（这是通常网上不正确的汉化包使用方法）
* 不需要重命名替换

#### 汉字乱码/中文显示为框框

当前字体不支持中文显示，请到 File → Settings → Appearance & Behavior → Appearance →  
勾选 Override default fonts by (not recommended): 选择 Microsoft YaHei 或者其他显示为框框的中文字体。
