title: IOS13.3 Beta4更新
date: '2019-12-09 19:46:16'
updated: '2019-12-10 15:05:27'
tags: [IOS]
permalink: /articles/2019/12/09/1575891976367.html
---
![](https://img.hacpai.com/bing/20181116.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

Beta4是目前版本里面最流畅的一版了，那么正式版也就不远了

> 下面是发现的不同点
在信息列表，向右滑动界面可以得到分类列表，和邮箱列表分类很像，不知道大家发现了没有

![image.png](https://img.hacpai.com/file/2019/12/image-263a4ca5.png)

