title: macOS 10.15 不能打开软件提示无法打开“app”，因为Apple无法检查其是否包含恶意软件。“移到废纸篓”无法打开的解决方法！
date: '2019-12-05 21:14:36'
updated: '2019-12-05 21:14:36'
tags: [技术分享]
permalink: /articles/2019/12/05/1575551676610.html
---

大家都已经升级到MacOS10.15了，然后呢，很多不兼容，软件打不开的情况就出现了。
这里给大家提供MacOS 10.15下不能打开软件，提示“移到废纸篓”无法打开的解决方法！和无法打开“core keygen.app”，因为Apple无法检查其是否包含恶意软件的解决办法。
1、打开终端
2、把你想要打开的软件拖入这行代码后面，记住有个空格隔开sudo xattr -rd com.apple.quarantine 复制代码
3、格式为：sudo xattr -rd com.apple.quarantine /你的软件路径.app
4、回车输入管理员密码
5、ok，执行完成现在你又能愉快的用上你心爱的软件了。


