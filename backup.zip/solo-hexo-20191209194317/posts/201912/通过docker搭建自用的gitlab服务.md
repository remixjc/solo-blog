title: 通过 docker 搭建自用的 gitlab 服务
date: '2019-12-09 09:33:36'
updated: '2019-12-09 09:52:08'
tags: [gitlab, docker]
permalink: /articles/2019/12/09/1575855216596.html
---
![](https://img.hacpai.com/bing/20190807.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言

git 是当下如日中天的版本管理系统。现在如果不是工作在 git 版本管理系统之下，几乎都不好意思和人打招呼了。有很多现成的互联网的 git 服务提供给大家使用，例如号称程序员社交网络的 GitHub，还有低调好用的 bitbucket 。这些给个人使用或者公司用来做开源使用都没有什么问题。但如果在部门内推广使用就会涉及到代码不能公开或者额外的费用的问题。本人原来在部门内采用的是手工在 linux 服务器上来管理代码仓库。权限没法设置，也非常不方便。所以也一直很苦恼。

正好 gitlab 公司提供了 gitlab 社区版，看了看基本满足了部门内 git 管理的需求。gitlab 提供了各种各样的安装方式，最方便的当然还是 docker 方式的安装，适合我这种不想多折腾的。抽空搭建了一个。也趟了几个坑，将步骤记录如下，希望对其他有此需求的人有所帮助。

## docker 安装

既然是基于 docker 来安装 gitlab ，首先是安装 docker 环境了。我是在 centos 7 的基础上安装的。根据[官网的指南](https://docs.docker.com/engine/installation/linux/docker-ce/centos/)

#### 删除旧版本的 docker

旧版本的 docker 的叫做 docker 或者 docker-engine，如果系统中已经安装旧版本，则需要删除。通过一下命令删除旧的 docker 版本

```
yum remove docker docker-common docker-selinux docker-engine
复制代码
```

#### 增加 docker yum 源

新的 docker 叫做 docker-ce ，如果第一次安装 docker-ce 需要设置 docker-ce 的 yum 源。用如下的命令来增加 docker-ce 的yum 源

```
yum install -y yum-utils device-mapper-persistent-data lvm2
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
yum-config-manager --enable docker-ce-edge
yum-config-manager --enable docker-ce-test
复制代码
```

#### 安装 dokcer-ce

首先我们查看所有有效的 docker-ce 的版本

```
yum list docker-ce --showduplicates | sort -r
复制代码
```

得到如下的列表

```
docker-ce.x86_64         17.12.0.ce-1.el7.centos              docker-ce-test   
docker-ce.x86_64         17.12.0.ce-1.el7.centos               docker-ce-stable 
docker-ce.x86_64         17.12.0.ce-1.el7.centos               @docker-ce-stable
docker-ce.x86_64         17.12.0.ce-0.4.rc4.el7.centos         docker-ce-test   
docker-ce.x86_64         17.12.0.ce-0.3.rc3.el7.centos         docker-ce-test   
docker-ce.x86_64         17.12.0.ce-0.2.rc2.el7.centos         docker-ce-test   
docker-ce.x86_64         17.12.0.ce-0.1.rc1.el7.centos         docker-ce-test   
docker-ce.x86_64         17.11.0.ce-1.el7.centos               docker-ce-test   
docker-ce.x86_64         17.11.0.ce-0.4.rc4.el7.centos         docker-ce-test   
...
docker-ce.x86_64         17.03.1.ce-0.1.rc1.el7.centos         docker-ce-test   
docker-ce.x86_64         17.03.0.ce-1.el7.centos               docker-ce-stable
复制代码
```

从这里可以看到最新的稳定版本是 17.12.0.ce。我们用下面的命令选择安装该版本

```
yum install docker-ce-17.12.0.ce
复制代码
```

#### 自定义 docker 配置

因为众所周知的原因，访问 docker 的中央仓库下载 docker 镜像的速度非常慢。为了获得较好的体验，我们需要配置一个寻找一个国内的镜像加速服务。

默认情况下，docker 将运行的目录配置到了/var/lib/docker 目录下。通常这个目录是在 linux 的根分区下，空间比较有限，所以我们需要将 docker 的运行目录配置到其他目录下。

镜像加速服务可以使用阿里云的镜像加速服务。注册阿里云的用户后，登录 https://cr.console.aliyun.com ，在管理控制台选择镜像加速服务，则出现如下的信息。这里红色打码部分就是你的阿里云镜像加速服务的地址。

![阿里云镜像加速服务](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c331d4aaa?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

为了自定义 docker 的默认运行目录和镜像仓库地址，我们需要修改 /etc/docker/daemon.json

```
mkdir /etc/docker
vi /etc/docker/daemon.json
复制代码
```

输入如下内容

```
{
  "graph":"/u1/docker",
  "registry-mirrors": ["https://xxxxxx.mirror.aliyuncs.com"]
}
复制代码
```

graph 定义 docker 运行的目录， registry-mirrors 定义了 docker 获取镜像的仓库的地址。

#### 启动 docker

执行如下的命令启动 docker 的服务

```
systemctl start docker
复制代码
```

执行如下命令查看 docker 信息

```
docker info
复制代码
```

可以看到如下的信息

![docker 信息](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c34b1c241?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

可以看到 Docker Root Dir 和 RegistryMirrors 都变成了 /etc/docker/daemon.json 中配置的内容了

## 安装 gitlab

#### 下载镜像

执行下面的命令，从 docker 的镜像仓库中下载 gitlab 社区版的镜像

```
docker pull gitlab/gitlab-ce:latest
复制代码
```

镜像有 1g 多，所以需要等待一段时间

#### 数据持久化保存

因为容器的数据是不能持久化保存的。所以我们需要用 docker volume 的方式将存储的数据映射到操作系统的目录中来。这样就算运行的容器崩溃，我们重新启动一个新的容器，原来容器中的数据还是不会丢失

我们建立了目录 /u1/gitlab 来保存 gitlab 容器中的数据

#### 准备映射 sshd

另外，为了 git 采用 ssh 协议来操作 git 仓库，我们将主机的 sshd 的 22 端口映射到 容器中去。将主机的 sshd 端口更改为 15678。这里因为 centos 7 更严格的安全机制，算是一个坑，需要按照下面的步骤去进行。

编辑文件 /etc/ssh/sshd_config，将其中的 #Port 22 注释去掉，将数字 22 更改为 15678

执行下面的命令重启 sshd 服务

```
systemctl restart sshd
复制代码
```

运行下面的命令使 15678 端口可以对外提供服务。否则无法进行远程的 ssh 登录。

```
semanage port -a -t ssh_port_t -p tcp 15678
firewall-cmd --permanent --add-port=15678/tcp
firewall-cmd --reload 
复制代码
```

#### 运行 gitlab

```
docker run \
    --publish 443:443 --publish 80:80 --publish 22:22 \
    --name gitlab \
    --volume /u1/gitlab/config:/etc/gitlab \
    --volume /u1/gitlab/logs:/var/log/gitlab \
    --volume /u1/gitlab/data:/var/opt/gitlab \
    gitlab/gitlab-ce
复制代码
```

这里把主机的 443、80、22 端口直接转发到容器，同时利用 --volume /u1/gitlab/config:/etc/gitlab 、 --volume /u1/gitlab/logs:/var/log/gitlab 、 --volume /u1/gitlab/data:/var/opt/gitlab 这三个参数将 gitlab 的配置、数据和日志持久化到主机文件系统上来。

## 管理员配置 gitlab

#### 登录 gitlab

等待 docker 容器启动完成后，访问 http://ip 就进入 gitlab 访问界面。第一次访问是让我们修改管理员密码。如下所示

![初始化 gitlab 管理员密码](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c34007f07?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

设置后管理员密码后，就进入登录页面，输入用户名 root 和刚才设置的密码就进入了 gitlab 的控制台。如下图所示

![gitlab 管理员控制台](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c341442fa?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

#### 创建组（ group）

gitlab 里面有三类对象：组（ group）、项目（ project）和用户 （people）。

为了方便管理，我们应该基于组来创建项目。一个项目就是一个 git 的仓库。基于组创建项目 ，然后将用户设置合适的权限后加入到组里面。这样用户就有了组里面所有项目的对应权限。

点击 “Create a group” 链接，如下图所示创建一个“健康医疗开发组” 的组

![gitlab 创建组](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c342e3135?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

#### 创建用户（people）

点击 “Add people” 链接，如下图所示创建一个 “yanggch” 的用户

![gitlab 增加用户](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c33b92f5b?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

因为还没有配置好邮件服务，所以还不能发送用户初始化密码的邮件。我们需要编辑用户，手动设置一个密码。如下图所示。如果用户忘记了密码，充值密码也可以在这里进行。

![gitlab 修改用户信息](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c5ff48753?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

#### 将用户加入组

为了方便管理，需要将用户加入到对应的组里面。如下图所示，在组管理界面中，点击组的名称，进入组用户设置界面。将刚才创建的用户 “yanggch” 加入到组 “健康医疗开发组”中，并且给他设置为 “Master” 角色。只有 “Master” 或者 “Owner” 角色才能推送 git 的更新。

![image.png](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c62f2a666?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

#### 创建项目（project）

增加 gitlab 组的时候，为了让项目让组里面的人都能访问，注意要将项目建立在组之下。如下图所示，在“健康医疗开发组”之下建立了 “redis_util” 的项目。

![gitlab 创建项目](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c624edcd6?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

这样项目建好之后就可以被组里的用户访问了。

## 客户端访问

#### 安装 git 客户端

这里演示在 window上安装 git 客户端。首先根据 window 版本下载 git 客户端安装程序。这里我下载的是

```
https://github.com/git-for-windows/git/releases/download/v2.15.1.windows.2/Git-2.15.1.2-64-bit.exe
复制代码
```

#### 命令行访问

安装后，在准备 clone 项目的目录下点击鼠标右键，出现下面的右键菜单。

![右键菜单](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c692aa937?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

点击 “Git Bash Here” 进入 git 命令行环境。我们会从 redis_util 项目中看到该项目基于 http 协议的 clone 命令是

```
git clone http://7a45cd079bdc/healthcare_dev/redis_util.git
复制代码
```

这里的 7a45cd079bdc 实际上是 docker 容器的机器名。实际执行的时候我们把这个字符串更换成容器所在主机的 ip 地址即可。如下所示

```
git clone http://10.110.2.50/healthcare_dev/redis_util.git
复制代码
```

这种情况下会要求输入登录的用户名和密码。这里输入刚才创建的用户的用户名和密码即可。在使用前，需要用这个用户登录 gitlab 控制台修改一下初始密码才能使用。

![gitlab http 权限验证](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c6a1cfe5e?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

出现如下提示表示从 gitlab clone 项目成功

```
Cloning into 'redis_util'...
warning: You appear to have cloned an empty repository.
复制代码
```

#### 免密码登录

刚才那种方式通过 http 协议和 gitlab 进行通信，每次都要输入用户名和密码，非常不方便。用户可以设置通过 ssh 进行交互，将ssh key 加入到用户的 sshkey 设置列表中。

参考“命令访问” 章节进入 git 的 bash 环境。执行下面的命令进入 ssh key 存储目录

```
cd ~/.ssh
复制代码
```

目录中 id_rsa.pub 是 ssh 访问的公钥。如果不存在则执行下面的命令生成

```
ssh-keygen -t rsa
复制代码
```

全部回车后，会生成 id_rsa.pub 文件。

将文件中的内容拷贝到剪贴板。然后通过前面创建的用户名和密码登录 gitlab 控制台。在下面的界面中，将 id_rsa.pub 文件的内容填入文本框

![配置用户 ssh key](data:image/svg+xml;utf8,<?xml version="1.0"?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="1240" height="502"></svg>)

保存后。再通过 ssh 协议操作 git 仓库，将不再需要输入用户名和密码。如下所示

![免登陆操作 gitlab 仓库](data:image/svg+xml;utf8,<?xml version="1.0"?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="439" height="88"></svg>)

#### 推送一次提交

首先配置当前仓库的用户名和用户邮箱配置

```
cd redis_util
git config --local user.name "yanggch"
git config --local user.email "yanggch@inspur.com"
复制代码
```

然后在 redis_util 目录下加入一个 readme.txt，执行下面的命令提交并将更新推送到 gitlab 远程服务器

```
#将新文件加入到版本管理
git add readme.txt
#提交
git commit -m"第一次提交"
#将当前分支 master 推送到远程仓库
git push
#以 master 分支为基础建立一个新的 dev 本地分支
git checkout -b dev
#将本地仓库分支推送到远程仓库，在远程仓库建立对应的 dev 分支
git push --set-upstream origin dev
复制代码
```

到 gitlab 控制台查看 redis_util 的状态。如下图所示

![redis_util 分支状况](https://user-gold-cdn.xitu.io/2018/1/3/160bb50c82f224b7?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

到此，我们就完成了一个公司级别的 gitlab 服务器的搭建工作。小伙伴们就可以在这个上面流畅的进行开发了。

**原文发表在简书中，[原始链接](https://www.jianshu.com/p/8d8e6b45a514)**

  
