title: Docker数据库备份
date: '2019-12-10 14:42:07'
updated: '2019-12-10 14:42:07'
tags: [Docker, Mysql, 备份]
permalink: /articles/2019/12/10/1575960127616.html
---
## 关于数据库备份

数据库备份是一件很小却很重要的事情，任何的数据存在都是有价值的，数据的价值只有在备份后才会体现。

## 操作方法

#### 第一次备份脚本

直接执行可以备份成功，当使用定时任务进行备份的时候，备份的文件为空，也就是说没有`mysqldump`出内容

```
#!/bin/bash
docker_name=mysql_container
data_dir=/home/ubuntu/mysql_dump
/usr/bin/docker exec -it $docker_name mysqldump -u username -p password --all-databases > "$data_dir/data_`date +%Y%m%d`.sql"
find $data_dir -mtime +7 -name 'data_*.sql' -exec rm {} \;
```

#### 第二次备份脚本

修改备份脚本，通过在容器内执行`mysqldump`，并备份到容器内`/var/local`目录下，再把此目录映射到宿主目录`/home/ubuntu/.data/mysql_dump`即可

```
#!/bin/bash
docker_name=mysql_container
data_dir=/home/ubuntu/.data/mysql_dump
/usr/bin/docker exec $docker_name sh -c "mysqldump -u username -p password --all-databases > /var/local/data_`date +%Y%m%d`.sql"
find $data_dir -mtime +7 -name 'data_*.sql' -exec sudo rm {} \;
```


