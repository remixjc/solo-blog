title: Linux CentOS 通过Docker 部署安装solo博客（非nginx版本）
date: '2019-11-17 17:27:48'
updated: '2019-11-21 17:10:07'
tags: [技术分享]
permalink: /articles/2019/11/17/1573982868351.html
---
Hello，大家好：
	经过了一些时间的花费，算是磕磕绊绊完整的通过linux系统（这里主要说的是CentOS）安装Docker后部署solo个人博客程序成功。

	话不多说直入主题。

 我们需要准备**Linux**系统，我这里用的是**CentOS**

首先可以通过ssh root@ip的方式登陆到linux系统
用yum命令来安装docker

	yum update  //注释：首先将yum更新
	yum install docker  //注释：直接通过yum安装docker

有网上是有很多复杂的安装方法，其实现在都已经变简单了，如果安装过要卸载的话可以自行搜索。

安装后需要启用Docker

	systemctl start docker  //注释： 启动docker

docker启动后，我们直接安装mysql，目前安装的最新版可以满足

	docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123456 -d mysql

mysql数据库安装完后需要进入到mysql创建数据库 solo

	docker exec -it mysql bash  //注释：进入到mysql容器
	mysql -uroot -p123456  //注释：登陆mysql
	create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;  //注释：创建数据库solo
	exit  //注释：退出数据库；
	exit  //注释：退出容器；

数据库创建好之后就可以直接安装solo了。

	docker run --detach --name solo --network=host \
	--env RUNTIME_DB="MYSQL" \
	--env JDBC_USERNAME="root" \
	--env JDBC_PASSWORD="yourpassword" \
	--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
	--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF8&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true" \
	b3log/solo --listen_port=8080 --server_scheme=http --server_host=127.0.0.1:8080

上面的--server_host=127.0.0.1:8080 可以直接换为域名，很多人在这一步会卡住，执行完了之后看不到docker容器有启动，是因为设置了端口号的问题，如果没有通过nginx对端口号和域名映射绑定，就老实的把端口号加上，不然请求的js等资源不对，就会访问不到。
查看docker容器命令如下：

	docker ps //注释：运行中的容器
	docker ps -a  //注释：所有已经安装的容器

此时会看到names为solo的容器，正常访问你的域名或者ip即可。

![image.png](https://img.hacpai.com/file/2019/11/image-106027bd.png)


看到这里是不是发现很简单呢

下面把会用到的命令分享给大家：

	docker rm solo  //注释：删除names为solo的容器，便于重新安装
	docker stop solo  //注释：删除容器前需要先停掉solo
	docker start solo  //注释：如果安装完solo没有启动，可以通过start命令启动
	docker logs solo  //注释：可以直接查看容器的日志
	docker logs -f solo  //注释：可以监测容器的日志变化，ctrl c取消。

大家还有什么疑问可以直接留言哦。


